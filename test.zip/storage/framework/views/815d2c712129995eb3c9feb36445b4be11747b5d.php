<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <form method="post" action="<?php echo e(route('transaction.store')); ?>">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-right">
                    <button type="submit" class="btn btn-success btn-sm">
                        <i class="material-icons">refresh</i> Refresh
                    </button>
                </div>
            </div>
        </form>
        <div class="row">
            <div class="col-md-12">
                
                <div class="text-center">
                    <?php echo $__env->make('errors.submit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">receipt</i>
                        </div>
                        <h4 class="card-title">User Tracking / Transaksi</h4>
                    </div>
                    <div class="card-body">
                        <div class="material-datatables">
                            <table id="yajra-datatable" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>NO</th>
                                        <th>TRANSACTION-ID</th>
                                        <th>BOOTH</th>
                                        <th>PAKET</th>
                                        <th>PAGE</th>
                                        <th>TOTAL</th>
                                        <th>DATE/TIME CREATED</th>
                                        <th>DATE/TIME UPDATED</th>
                                        <th>STATUS</th>
                                        <th class="text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function onStartChange() {
        var start = document.getElementById("tgl-start").value;
        document.getElementById("tgl-end").setAttribute("min", start);
    }

    function onEndChange() {
        var end = document.getElementById("tgl-end").value;
        document.getElementById("tgl-start").setAttribute("max", end);
    }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(function(){
            $('#yajra-datatable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('transaction.index')); ?>",
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex' },
                    { data: 'trx_id', name: 'trx_id' },
                    { data: 'booth_name', name: 'booth_name' },
                    { data: 'package_name', name: 'package_name' },
                    { data: 'page', name: 'page' },
                    { data: 'amount', name: 'amount' },
                    { data: 'created_at', name: 'created_at' },
                    { data: 'updated_at', name: 'updated_at' },
                    { data: 'status', name: 'status' },
                    {
                        data: '',
                        name: '',
                        render: (data, type, row) => {
                            return `<a href="/transaction/${row.id}" class="edit btn btn-primary btn-sm"><i class="material-icons">info</i></a>`
                        }
                    },
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dev.photo\resources\views/backend/menu/transaction/list.blade.php ENDPATH**/ ?>