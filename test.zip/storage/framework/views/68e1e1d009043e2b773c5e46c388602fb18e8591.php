<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
    <div class="container-fluid">
        <div class="navbar-wrapper">
            <div class="navbar-minimize">
                <button id="minimizeSidebar" class="btn btn-just-icon btn-white btn-fab btn-round">
                    <i class="material-icons text_align-center visible-on-sidebar-regular">more_vert</i>
                    <i class="material-icons design_bullet-list-67 visible-on-sidebar-mini">view_list</i>
                </button>
            </div>
            <a class="navbar-brand" href="javascript:;">
                <?php echo e((request()->segment(1) == 'home') ? 'Dashboard' : ''); ?>

                <?php echo e((request()->segment(1) == 'booth') ? 'Booth' : ''); ?>

                <?php echo e((request()->segment(1) == 'transaction') ? 'User Tracking / Transaksi' : ''); ?>

                <?php echo e((request()->segment(1) == 'user') ? 'User Management' : ''); ?>

                <?php echo e((request()->segment(1) == 'list-guest') ? 'List Guests' : ''); ?>

                <?php echo e((request()->segment(1) == 'list-contact') ? 'List Forms' : ''); ?>

                <?php echo e((request()->segment(1) == 'my-profile') ? 'My Profile' : ''); ?>

                <?php echo e((request()->segment(1) == 'change-password') ? 'Change Password' : ''); ?>

                <?php echo e((request()->segment(1) == 'color') ? 'Color Filter' : ''); ?>

                <?php echo e((request()->segment(1) == 'frame') ? 'Image Frame' : ''); ?>

                <?php echo e((request()->segment(1) == 'voucher') ? 'Data Voucher' : ''); ?>

                <?php echo e((request()->segment(1) == 'package') ? 'Paket' : ''); ?>

            </a>
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
        </button>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\project\dev.photo\resources\views/backend/template/navbar.blade.php ENDPATH**/ ?>