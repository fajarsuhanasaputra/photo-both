<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('backend.template.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form id="RegisterValidation" method="post" action="<?php echo e(route('voucher.store')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="card ">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">wallpaper</i>
                            </div>
                            <h4 class="card-title">Form Add Color</h4>
                        </div>
                        <div class="card-body ">
                            <div class="row">

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="exampleprice" class="bmd-label-floating"> Type*</label>
                                        <input disabled type="text" name="type" class="form-control" required placeholder="Percent">
                                        <?php if($errors->has('type')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('type')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleName" class="bmd-label-floating"> Code*</label>
                                        <input type="text" name="code" id="exampleName" class="form-control">
                                        <?php if($errors->has('code')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('code')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleName" class="bmd-label-floating"> Value*</label>
                                        <input type="text" name="value" id="exampleName" class="form-control">
                                        <?php if($errors->has('value')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('value')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleName" class="bmd-label-floating"> Start*</label>
                                        <input type="date" name="start" id="exampleName" class="form-control">
                                        <?php if($errors->has('start')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('start')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleName" class="bmd-label-floating"> Expired*</label>
                                        <input type="date" name="expired" id="exampleName" class="form-control">
                                        <?php if($errors->has('expired')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('expired')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-success btn-sm"><i class="material-icons">save</i> Save</button>
                            <a href="<?php echo e(route('voucher.index')); ?>" class="btn btn-sm btn-danger"><i class="material-icons">west</i> Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dev.photo\resources\views/backend/menu/settings/voucher/add.blade.php ENDPATH**/ ?>