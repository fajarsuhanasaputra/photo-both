<footer class="footer">
    <div class="container-fluid">
        <nav class="float-left">
            <!--            <ul>
                            <li>
                                <a href="https://www.creative-tim.com/">
                                    Creative Tim
                                </a>
                            </li>
                            <li>
                                <a href="https://www.creative-tim.com/presentation">
                                    About Us
                                </a>
                            </li>
                            <li>
                                <a href="https://www.creative-tim.com/blog">
                                    Blog
                                </a>
                            </li>
                            <li>
                                <a href="https://www.creative-tim.com/license">
                                    Licenses
                                </a>
                            </li>
                        </ul>-->
        </nav>
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            Matoaphotobooth
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\project\dev.photo\resources\views/backend/template/footer.blade.php ENDPATH**/ ?>