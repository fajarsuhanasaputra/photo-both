<meta charset="utf-8" />
<link rel="apple-touch-icon" sizes="76x76" href="{{ (asset('public/assets/img/apple-icon.png')) }}">
<link rel="icon" type="image/png" href="{{ (asset('public/assets/img/favicon.png')) }}">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>
    Admin
</title>
<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="{{ (asset('public/assets/css/material-dashboard.min1c51.css?v=2.1.2')) }}" rel="stylesheet" />
<link href="{{ (asset('public/assets/demo/demo.css')) }}" rel="stylesheet" />
