<?php

namespace App\Models\Images;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ImagePrint extends Model {

    use HasFactory;

    protected $guarded = [''];

}
