<?php $__env->startSection('sub-title'); ?>
- Add Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('backend.template.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form id="RegisterValidation" method="post" action="<?php echo e(route('user.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="card ">
                        <div class="card-header card-header-info card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">group</i>
                            </div>
                            <h4 class="card-title">Form Add User</h4>
                        </div>
                        <div class="card-body ">
                            <div class="row">

                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="name" class="bmd-label-floating"> Username *</label>
                                        <input type="text" name="name" id="name" autocomplete="off" class="form-control" value="<?php echo e(old('name', isset($role) ? $role->name : '')); ?>" required>
                                        <?php if($errors->has('name')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('name')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                        <label for="exampleEmail" class="bmd-label-floating"> Email *</label>
                                        <input type="email" name="email" id="exampleEmail" autocomplete="off" class="form-control" value="<?php echo e(old('email', isset($role) ? $role->email : '')); ?>" required>
                                        <?php if($errors->has('email')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('email')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-12 mt-4">
                                    <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                        <label for="password" class="bmd-label-floating"> Password *</label>
                                        <input type="password" name="password" id="password" autocomplete="off" required class="form-control">
                                        <?php if($errors->has('password')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('password')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-12 mt-1">
                                    <div class="form-group <?php echo e($errors->has('roles') ? 'has-error' : ''); ?>">
                                        <label>Role : </label>
                                        <select name="roles[]" id="roles" class="selectpicker" data-style="btn btn-success btn-round btn-sm" title="Select Role" required>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('roles', [])) || isset($user) && $user->roles->contains($id)) ? 'selected' : ''); ?>><?php echo e($roles); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <?php if($errors->has('roles')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('roles')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <hr>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-success btn-sm"><i class="material-icons">save</i> Save</button>
                            <a href="<?php echo e(route('user.index')); ?>" class="btn btn-sm btn-danger"><i class="material-icons">west</i> Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dev.photo\resources\views/backend/menu/management/user/add.blade.php ENDPATH**/ ?>