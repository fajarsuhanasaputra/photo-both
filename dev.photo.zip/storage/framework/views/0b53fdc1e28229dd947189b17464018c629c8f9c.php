<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('backend.template.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form id="RegisterValidation" method="post" action="<?php echo e(route('package.store')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="card ">
                        <div class="card-header card-header-rose card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">wallpaper</i>
                            </div>
                            <h4 class="card-title">Form Edit Color</h4>
                        </div>
                        <div class="card-body ">
                            <div class="row">

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="exampleprice" class="bmd-label-floating"> Package Name*</label>
                                        <input type="text" class="form-control" required name="package_name">
                                        <?php if($errors->has('package_name')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('package_name')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleName" class="bmd-label-floating"> Price*</label>
                                        <input type="text" name="price" id="exampleName" class="form-control">
                                        <?php if($errors->has('price')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('price')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleName" class="bmd-label-floating"> Total*</label>
                                        <input type="text" name="total" id="exampleName" class="form-control">
                                        <?php if($errors->has('total')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('total')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleName" class="bmd-label-floating"> Description*</label>
                                        <textarea class="form-control" name="description"></textarea>
                                        <?php if($errors->has('description')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('description')); ?>

                                        </em>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-success btn-sm"><i class="material-icons">save</i> Save</button>
                            <a href="<?php echo e(route('package.index')); ?>" class="btn btn-sm btn-danger"><i class="material-icons">west</i> Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dev.photo\resources\views/backend/menu/package/add.blade.php ENDPATH**/ ?>