<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="text-right">
                    <a href="<?php echo e(route('color.create')); ?>" class="btn btn-sm btn-round btn-success">
                        <i class="material-icons">add_circle</i> Color</a>
                </div>
                
                <!--  end card  -->
                <div class="card">
                    <div class="card-header card-header-primary card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">format_color_fill</i>
                        </div>
                        <h4 class="card-title">List Color</h4>
                    </div>
                    <div class="card-body">
                        <div class="material-datatables">
                            <table id="yajra-datatable" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Hex</th>
                                        <th>Color</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">

    var table;
        $(function(){

            table = $('#yajra-datatable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('color.index')); ?>",
                columns: [
                    { data: 'id', name: 'id' },
                    { data: 'name', name: 'name' },
                    { data: 'hex', name: 'hex' },
                    { data: 'color', name: 'color' },
                    { data: 'action', name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });

            $('#yajra-datatable').on('click', '.delete-color', function () {
                var row = $(this).closest('tr');
                var colorId = table.row(row).data().id;

                if (confirm("Are you sure you want to delete this color?")) {
                    $.ajax({
                        url: "<?php echo e(route('color.destroy', ['color' => 0])); ?>".replace('0', colorId),
                        type: "POST",
                        data: {
                            "_method": 'DELETE',
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function (data) {
                            table.ajax.reload();
                            alert(data.message); // You can replace this with a more user-friendly notification
                        },
                        error: function (data) {
                            console.log('Error:', data);
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\dev.photo\resources\views/backend/menu/master/color/list.blade.php ENDPATH**/ ?>