<div class="sidebar" data-color="rose" data-background-color="black" data-image="<?php echo e((asset('assets/img/sidebar-1.jpg'))); ?>">
    <div class="logo">
        <a href="#" class="simple-text logo-mini">
            MPB
        </a>
        <a href="#" class="simple-text logo-normal">
            MATOAPHOTOBOOTH
        </a>
    </div>
    <div class="sidebar-wrapper">
        <div class="user">

            <div class="user-info">
                <ul class="nav">
                    <li class="nav-item <?php echo e((request()->segment(1) == 'my-profile') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(route('my-profile')); ?>">
                            <span class="sidebar-normal"> <?php echo e(Auth::user()->name); ?> </span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <ul class="nav">
            <li class="nav-item <?php echo e((request()->segment(1) == 'home') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p> Dashboard </p>
                </a>
            </li>

            <li class="nav-item <?php echo e((request()->segment(1) == 'transaction') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('transaction.index')); ?>">
                    <i class="material-icons">map</i>
                    <p> User Tracking / Transaksi </p>
                </a>
            </li>

            <li class="nav-item <?php echo e((request()->segment(1) == 'list-contact') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('list-contact.index')); ?>">
                    <i class="material-icons">contact_mail</i>
                    <p> List Form </p>
                </a>
            </li>


            <li class="nav-item <?php echo e((request()->segment(1) == 'booth') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('booth.index')); ?>">
                    <i class="material-icons">work</i>
                    <p> Booth Management</p>
                </a>
            </li>

            <li class="nav-item <?php echo e((request()->segment(1) == 'user') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                    <span class="sidebar-mini">
                        <i class="material-icons">manage_accounts</i>
                    </span>
                    <span class="sidebar-normal"> Users Management</span>
                </a>
            </li>

            <li class="nav-item <?php echo e((request()->segment(1) == 'package') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('package.index')); ?>">
                    <i class="material-icons">percent</i>
                    <p> Paket </p>
                </a>
            </li>


            <li class="nav-item <?php echo e((request()->segment(1) == 'color') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('color.index')); ?>">
                    <span class="sidebar-mini">
                        <i class="material-icons">format_color_fill</i>
                    </span>
                    <span class="sidebar-normal"> Color Filter </span>
                </a>
            </li>

            <li class="nav-item <?php echo e((request()->segment(1) == 'frame') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('frame.index')); ?>">
                    <span class="sidebar-mini">
                        <i class="material-icons">wallpaper</i>
                    </span>
                    <span class="sidebar-normal"> Image Frame </span>
                </a>
            </li>


            <li class="nav-item <?php echo e((request()->segment(1) == 'voucher') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('voucher.index')); ?>">
                    <i class="material-icons">money</i>
                    <p> Data Voucher </p>
                </a>
            </li>

        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\project\dev.photo\resources\views/backend/template/sidebar.blade.php ENDPATH**/ ?>